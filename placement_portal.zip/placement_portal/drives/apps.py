from django.apps import AppConfig


class DrivesConfig(AppConfig):
    name = 'drives'
